import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class AtomAnimation extends PApplet {

private PVector cameraPos; //camera position
private float scaleFactor; //zoom scale factor
private AtomModel[][] models; //list of all the models
private int modelsIndexHoriz; //which model the camera is currently viewing
private int modelsIndexVert;
private PVector targetPos; //Position for the camera to move to
private float cameraRotY, cameraRotX; //camera's rotation in X and Y planes

public void setup()
{
    //Boring init stuff
    
    textMode(SHAPE);
    
    scaleFactor = 1.8f;
    
    models = new AtomModel[5][3];
    models[0][0] = new DaltonModel();
    models[1][0] = new ThomsonModel();
    models[2][0] = new RutherfordModel();
    models[2][1] = new RutherfordModel(1, 1, 1);
    models[3][0] = new BohrModel();
    models[4][0] = new QuantumMechanicsModelSOrbital();
    models[4][1] = new QuantumMechanicsModelPOrbital();
    models[4][2] = new QuantumMechanicsModelSOrbital(new PVector(900, height/2 + 140, 300));
    modelsIndexHoriz = 0;
    modelsIndexVert = 0;
    
    AtomModel targetModel = models[modelsIndexHoriz][modelsIndexVert];
    
    targetPos = new PVector(targetModel.position.x, targetModel.position.y, targetModel.position.z);
    cameraPos = targetPos;
    
    cameraRotY = 0;
    cameraRotX = 0;
}

public void draw()
{
    //set background and basic stroke colors
    background(0xff86A7FF);
    lights();
    stroke(0);

    pushMatrix();
    //scale based on zoom   
    translate(width / 2, height / 2);
    rotateY(cameraRotY);
    rotateX(cameraRotX);
    scale(scaleFactor);

    //move camera according to target position using fake interpolation :(
    cameraPos.x += (targetPos.x - cameraPos.x) / 10;
    cameraPos.y += (targetPos.y - cameraPos.y) / 10;
    cameraPos.z += (targetPos.z - cameraPos.z) / 5;
    translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);
    
    //camera(cameraPos.x, cameraPos.y, (height/2.0) / tan(PI*30.0 / 180.0), width/2.0, height/2.0, 0, 0, 1, 0);
    

    //draw all the models
    for (int i = 0; i < 5; i++)
    {
        for(int j = 0; j < 3; j++) //<>//
        {
            if(models[i][j] == null || models[i][j].position.dist(cameraPos) > 200)
                continue;
            models[i][j].drawModel();
        }
    }
    popMatrix();
       
    fill(0);
    //framerate debugger. ****REMOVE****
    text((int)frameRate, 12, 15);
}

public void keyPressed(KeyEvent e)
{
    if (e.getKeyCode() == LEFT && modelsIndexHoriz > 0 && models[modelsIndexHoriz-1][modelsIndexVert] != null)
        modelsIndexHoriz--;
    if (e.getKeyCode() == RIGHT && modelsIndexHoriz < models.length - 1 && models[modelsIndexHoriz+1][modelsIndexVert] != null)
        modelsIndexHoriz++;
    if (e.getKeyCode() == UP && modelsIndexVert > 0 && models[modelsIndexHoriz][modelsIndexVert-1] != null)
        modelsIndexVert--;
    if (e.getKeyCode() == DOWN && modelsIndexVert < 2 && models[modelsIndexHoriz][modelsIndexVert+1] != null)
        modelsIndexVert++;
    if (e.getKeyCode() == 'A')
        cameraRotY += PI/6;
    if (e.getKeyCode() == 'D')
        cameraRotY -= PI/6;
    if (e.getKeyCode() == 'W')
        cameraRotX -= PI/6;
    if (e.getKeyCode() == 'S')
        cameraRotX += PI/6;
    if (e.getKeyCode() == 'R')
        setup();

    AtomModel targetModel = models[modelsIndexHoriz][modelsIndexVert];
    if(targetModel != null)
        targetPos = targetModel.getPosition();
}

public void mouseWheel(MouseEvent event)
{
    scaleFactor += event.getCount()/60f;
    if(scaleFactor <= 1.8f)
        scaleFactor = 1.8f;
    if(scaleFactor >= 9)
        scaleFactor = 9;
}
public abstract class AtomModel
{
    private String name; //Name of the model
    private int radius; //Radius of the model
    private PVector position; //It's position in the world


    public AtomModel(String name, int radius, PVector position)
    {
        this.name = name;
        this.radius = radius;
        this.position = position;
    }

    /**
     *Draws the atom model
     */
    public void drawModel()
    {
        fill(0);
        textSize(15);
        textAlign(CENTER);
        text(getName(), position.x, height/2 + 60, getPosition().z);
    }
    
    //GETTERS AND SETTERS
    public String getName()
    {
        return name;
    }
    public PVector getPosition()
    {
        return position;
    }
    public int getRadius()
    {
        return radius;
    }
}
public class BohrElectron extends Particle
{
    private float orbitAngle;//angular position of particle
    private float orbitRadius;//radius of particle from center of atom
    private float angularVel;//velocity at which particle moves

    public BohrElectron(float orbitRadius)
    {
        super(new PVector(0, 0), new PVector(0, 0));
        orbitAngle = random(0, 2 * PI);
        this.orbitRadius = orbitRadius;
        angularVel = random(.05f, .1f);
    }

    @Override
    public void drawParticle()
    {
        //math for rotating electorns
        orbitAngle += angularVel;
        float x = orbitRadius*cos(orbitAngle);
        float y = orbitRadius*sin(orbitAngle);
        setPosition(new PVector(x, y));
        
        //draw the orbit ring
        noFill();
        stroke(1);
        ellipse(0, 0, orbitRadius*2, orbitRadius*2);
        
        //draw the electron
        noStroke();
        fill(204, 254, 255);
        pushMatrix();
        translate(getPosition().x, getPosition().y);
        sphere(getRadius());
        translate(-getPosition().x, -getPosition().y);
        popMatrix();
    }
}
public class BohrModel extends AtomModel
{
    private ArrayList<Particle> nucleusParticles; //array to hold the protons and nuetrons in nucleus
    private ArrayList<Particle> orbitalParticles; //array to hold the oribiting electrons

    private int numProtons = 1;
    private int numNeutrons = 1;
    private int numElectrons = 1;

    public BohrModel()
    {
        super("Bohr Model", 25, new PVector(700, height / 2));
        nucleusParticles = new ArrayList<Particle>();
        orbitalParticles = new ArrayList<Particle>();
        generateNucleus();
        for (int i = 1; i <= numElectrons; i++)
            orbitalParticles.add(new BohrElectron(i*15));
    }

    @Override
    public void drawModel()
    {
        super.drawModel();
        pushMatrix();
        translate(getPosition().x, getPosition().y);

        for (Particle p : nucleusParticles)
            p.drawParticle();
        for (Particle p : orbitalParticles)
            p.drawParticle();
        
        for(int i = 2; i < 4; i++)
        {
            //draw the orbit ring
            noFill();
            stroke(1);
            ellipse(0, 0, 30*i, 30*i);
        }
            
        popMatrix();
    }

    /**
     *Generates a nucleus for the atom model
     */
    private void generateNucleus()
    {    
        int radius = 3;
        //generate the neutrons for the model
        for (int i = 0; i < numNeutrons; i++)
        {
            float u = random(-1.0f, 1.0f);
            float theta = random(0, 2*PI);
            float x = sqrt(1-u*u)*cos(theta);
            float y = sqrt(1-u*u)*sin(theta);
            float z = u;

            PVector neutronPos = new PVector(x*radius, y*radius, z*radius);
            PVector neutronVel = new PVector(0, 0);
            BohrNeutron neutron = new BohrNeutron(neutronPos, neutronVel, 3);
            nucleusParticles.add(neutron);
        }

        //generate the protons for the model
        for (int i = 0; i < numProtons; i++)
        {

            float u = random(-1.0f, 1.0f);
            float theta = random(0, 2*PI);
            float x = sqrt(1-u*u)*cos(theta);
            float y = sqrt(1-u*u)*sin(theta);
            float z = u;

            PVector protonPos = new PVector(x*radius, y*radius, z*radius);
            PVector protonVel = new PVector(0, 0);
            BohrProton proton = new BohrProton(protonPos, protonVel, 3);
            nucleusParticles.add(proton);
        }
    }
}
public class BohrNeutron extends Particle
{
    public BohrNeutron(PVector position, PVector velocity, int radius)
    {
        super(position, velocity);
    }

    @Override
    public void drawParticle()
    {
        noStroke();
        fill(0xff4560E3);
        translate(getPosition().x, getPosition().y, getPosition().z);
        sphere(getRadius());
        stroke(0);
        translate(-getPosition().x, -getPosition().y, -getPosition().z);
    }
}
public class BohrProton extends Particle
{
    public BohrProton(PVector position, PVector velocity, int radius)
    {
        super(position, velocity);
    }

    @Override
    public void drawParticle()
    { 
        noStroke();
        fill(0xffE34545);
        translate(getPosition().x, getPosition().y, getPosition().z);
        sphere(getRadius());
        stroke(0);
        translate(-getPosition().x, -getPosition().y, -getPosition().z);
    }
}
public class DaltonModel extends AtomModel
{
    public DaltonModel()
    {
        super("Dalton Model", 45, new PVector(100, height / 2));
    }

    @Override
    public void drawModel()
    {
        super.drawModel();
        pushMatrix();
        translate(getPosition().x, getPosition().y);

        //draw the model
        fill(205, 103, 204);
        noStroke();
        sphere(getRadius());

        
        
        popMatrix();
    }
}
public abstract class Particle
{
    private PVector position; //position of particle relative to atom
    private PVector velocity; //velocity of particle relative to container
    private int radius; //radius of particle

    public Particle(PVector position, PVector velocity)
    {
        this.position = position;
        this.velocity = velocity;
        radius = 5;
    }

    /**
     *Draws the particle
     */
    public abstract void drawParticle();

    //GETTERS AND SETTERS
    public PVector getPosition()
    {
        return position;
    }
    
    public void setPosition(PVector position)
    {
        this.position = position;
    }
    
    public PVector getVelocity()
    {
        return velocity;
    }
    
    public void setVelocity(PVector velocity)
    {
        this.velocity = velocity;
    } 
    public int getRadius()
    {
        return radius;
    }
}
public class QuantumMechanicsElectron extends Particle
{
    public QuantumMechanicsElectron(PVector position, PVector velocity)
    {
        super(position, velocity);
    }

    @Override
    public void drawParticle()
    {
        //draw the electron
        noStroke();
        fill(204, 254, 255);
        pushMatrix();
        translate(getPosition().x, getPosition().y, getPosition().z);
        sphere(getRadius());
        translate(-getPosition().x, -getPosition().y, -getPosition().z);
        popMatrix();
    }
}
public class QuantumMechanicsElectronTrail extends Particle
{
    public QuantumMechanicsElectronTrail(PVector position, PVector velocity)
    {
        super(position, velocity);
    }

    @Override
    public void drawParticle()
    {
        stroke(0);
        strokeWeight(2);
        point(getPosition().x, getPosition().y, getPosition().z); 
        strokeWeight(1);
    }
}
public class QuantumMechanicsModelPOrbital extends AtomModel
{
    private ArrayList<QuantumMechanicsElectronTrail> electronTrails;
    private QuantumMechanicsElectron electron;
   
    
    private int numNeutrons = 3;
    private int numProtons = 3;
    private int numElectrons = 1;
    
    public QuantumMechanicsModelPOrbital()
    {
        super("Quantum Mechanics Model\nP Orbital", 9, new PVector(900, height / 2, 300));
        electronTrails = new ArrayList<QuantumMechanicsElectronTrail>();
        electron = new QuantumMechanicsElectron(new PVector(0, 0, 0), new PVector(0, 0, 0));
      
    }
    
    @Override
    public void drawModel()
    {
        super.drawModel();
        pushMatrix(); 
        translate(getPosition().x, getPosition().y, getPosition().z);

            
        if(electronTrails.size() == 500)
            electronTrails = new ArrayList();
        if(frameCount % 20 == 0)
        {   
            float u = random(-1.0f, 1.0f);
            float theta = random(0, 2*PI);
           
            float r = getRadius()*cos(2*theta);
            //float x = (r-(r*random(0, 1)))*cos(theta);
            //float y = (r-(r*random(0, 1)))*sin(theta);
            float x = r*cos(theta);
            float y = r*sin(theta);
            float z = 0;

            PVector elecPos = new PVector(x*5, y*5, z*5);
            PVector elecVel = new PVector(0, 0, 0);
            
            QuantumMechanicsElectronTrail electronTrail = new QuantumMechanicsElectronTrail(elecPos, elecVel);
            electronTrails.add(electronTrail);  
            
            electron.setPosition(elecPos);
            
        }
        for(QuantumMechanicsElectronTrail trail : electronTrails)
            trail.drawParticle();
        electron.drawParticle();
           
        popMatrix();
    }
}
public class QuantumMechanicsModelSOrbital extends AtomModel
{
    private ArrayList<Particle> nucleusParticles; //array to hold the oribiting electrons
    private ArrayList<QuantumMechanicsElectronTrail> electronTrails;
    private QuantumMechanicsElectron electron;

    private int numNeutrons = 3;
    private int numProtons = 3;
    private int numElectrons = 1;
    
    public QuantumMechanicsModelSOrbital()
    {
        super("Quantum Mechanics Model\nS Orbital", 40, new PVector(900, height / 2));
        nucleusParticles = new ArrayList<Particle>();
        electronTrails = new ArrayList<QuantumMechanicsElectronTrail>();
        electron = new QuantumMechanicsElectron(new PVector(0, 0, 0), new PVector(0, 0, 0));
        generateNucleus();
        
    }
    
    public QuantumMechanicsModelSOrbital(PVector position)
    {
        super("", 40, position);
        nucleusParticles = new ArrayList<Particle>();
        electronTrails = new ArrayList<QuantumMechanicsElectronTrail>();
        electron = new QuantumMechanicsElectron(new PVector(0, 0, 0), new PVector(0, 0, 0));
    }
   
    @Override
    public void drawModel()
    {
        super.drawModel();
        pushMatrix(); 
        translate(getPosition().x, getPosition().y, getPosition().z);
        
        for(Particle nucleusParticle : nucleusParticles)
           nucleusParticle.drawParticle();
            
        if(electronTrails.size() == 500)
            electronTrails = new ArrayList();
        if(frameCount % 20 == 0)
        {   
            float u = random(-1.0f, 1.0f);
            float theta = random(0, 2*PI);
            float x = sqrt(1-u*u)*cos(theta);
            float y = sqrt(1-u*u)*sin(theta);
            float z = u;

            PVector elecPos = new PVector(x*getRadius(), y*getRadius(), z*getRadius());
            PVector elecVel = new PVector(0, 0, 0);
            
            QuantumMechanicsElectronTrail electronTrail = new QuantumMechanicsElectronTrail(elecPos, elecVel);
            electronTrails.add(electronTrail);   
            
            electron.setPosition(elecPos);
            
        }
        for(QuantumMechanicsElectronTrail trail : electronTrails)
            trail.drawParticle();
        electron.drawParticle();
            
        //fill(0, 0, 0, 30);
        //noStroke();
        //rotateX(-PI/6);
        //sphere(getRadius());
        //rotateX(PI/6);
        popMatrix();
    }
    
     /**
     *Generates a nucleus for the atom model
     */
    private void generateNucleus()
    {    
        int radius = 3;
        //generate the neutrons for the model
        for (int i = 0; i < numNeutrons; i++)
        {
            float u = random(-1.0f, 1.0f);
            float theta = random(0, 2*PI);
            float x = sqrt(1-u*u)*cos(theta);
            float y = sqrt(1-u*u)*sin(theta);
            float z = u;

            PVector neutronPos = new PVector(x*radius, y*radius, z*radius);
            PVector neutronVel = new PVector(0, 0);
            QuantumMechanicsNeutron neutron = new QuantumMechanicsNeutron(neutronPos, neutronVel);
            nucleusParticles.add(neutron);
        }

        //generate the protons for the model
        for (int i = 0; i < numProtons; i++)
        {

            float u = random(-1.0f, 1.0f);
            float theta = random(0, 2*PI);
            float x = sqrt(1-u*u)*cos(theta);
            float y = sqrt(1-u*u)*sin(theta);
            float z = u;

            PVector protonPos = new PVector(x*radius, y*radius, z*radius);
            PVector protonVel = new PVector(0, 0);
            QuantumMechanicsProton proton = new QuantumMechanicsProton(protonPos, protonVel);
            nucleusParticles.add(proton);
        }
    }
}
public class QuantumMechanicsNeutron extends Particle
{
    public QuantumMechanicsNeutron(PVector position, PVector velocity)
    {
        super(position, velocity);
    }

    @Override
    public void drawParticle()
    {
        noStroke();
        fill(0xff4560E3);
        translate(getPosition().x, getPosition().y, getPosition().z);
        sphere(getRadius());
        stroke(0);
        translate(-getPosition().x, -getPosition().y, -getPosition().z);
    }
}
public class QuantumMechanicsProton extends Particle
{   
    public QuantumMechanicsProton(PVector position, PVector velocity)
    {
        super(position, velocity);
 
    }

    @Override
    public void drawParticle()
    {
        noStroke();
        fill(0xffE34545);
        translate(getPosition().x, getPosition().y, getPosition().z);
        sphere(getRadius());
        stroke(0);
        translate(-getPosition().x, -getPosition().y, -getPosition().z);
    }
   
}
public class RutherfordElectron extends Particle
{
    private float orbitAngle; //angular position of particle
    private float orbitRadius; //radius of particle from center of atom
    private float angularVel; //velocity at which particle moves
    private float orbitRotation; //angle at which the orbit occurs

    public RutherfordElectron(float orbitRotation)
    {
        super(new PVector(0, 0), new PVector(0, 0));
        orbitAngle = random(0, 2 * PI);
        orbitRadius = 45;
        angularVel = random(.05f, .1f);
        this.orbitRotation = orbitRotation;
    }

    @Override
    public void drawParticle()
    {
        //math for the basic particle rotation
        orbitAngle += angularVel;
        float x = orbitRadius*cos(orbitAngle);
        float y = orbitRadius/3f*sin(orbitAngle);
        setPosition(new PVector(x, y));

        //flip it around some axis
        rotateY(PI/2);
        rotateX(orbitRotation);
        rotateY(PI/3);

        //draw orbit ring
        noFill();
        ellipse(0, 0, orbitRadius*2, orbitRadius*2/3f);

        //draw electron
        noStroke();
        fill(204, 254, 255);
        translate(getPosition().x, getPosition().y);
        sphere(getRadius());
        stroke(0);
        translate(-getPosition().x, -getPosition().y);

        //unflip it around some axis
        rotateY(-PI/3);
        rotateX(-orbitRotation);
        rotateY(-PI/2);
    }
}
public class RutherfordModel extends AtomModel
{
    private ArrayList<Particle> nucleusParticles; 
    private ArrayList<Particle> orbitalParticles;

    private int numProtons;
    private int numNeutrons;
    private int numElectrons;

    public RutherfordModel()
    {
        super("Rutherford Model", 25, new PVector(500, height / 2));  
        nucleusParticles = new ArrayList<Particle>();
        orbitalParticles = new ArrayList<Particle>();
        numProtons = 3;
        numNeutrons = 3;
        numElectrons = 3;
        generateNucleus();
        for (int i = 0; i < numElectrons; i++)
            orbitalParticles.add(new RutherfordElectron(-PI/4+ 2*PI/numElectrons*i));
    }
    
    public RutherfordModel(int protons, int neutrons, int electrons)
    {
        super("", 25, new PVector(500, height*3/4));
        nucleusParticles = new ArrayList<Particle>();
        orbitalParticles = new ArrayList<Particle>();
        numProtons = protons;
        numNeutrons = neutrons;
        numElectrons = electrons;
        generateNucleus();
        for (int i = 0; i < numElectrons; i++)
            orbitalParticles.add(new RutherfordElectron(-PI/4+ 2*PI/numElectrons*i));
    }

    public void drawModel()
    {
        super.drawModel();
        pushMatrix();
        translate(getPosition().x, getPosition().y);

        for (Particle p : nucleusParticles)
            p.drawParticle();
        for (Particle p : orbitalParticles)
            p.drawParticle(); 
        popMatrix();
    }

    /**
     *Generates a nucleus for the atom model
     */
    private void generateNucleus()
    {   
        //generate the neutrons
        int radius = 5;
        for (int i = 0; i < numNeutrons; i++)
        {
            float u = random(-1.0f, 1.0f);
            float theta = random(0, 2*PI);
            float x = sqrt(1-u*u)*cos(theta);
            float y = sqrt(1-u*u)*sin(theta);
            float z = u;

            PVector neutronPos = new PVector(x*radius, y*radius, z*radius);
            PVector neutronVel = new PVector(0, 0);
            RutherfordNeutron neutron = new RutherfordNeutron(neutronPos, neutronVel, 3);
            nucleusParticles.add(neutron);
        }

        //generate the protons
        for (int i = 0; i < numProtons; i++)
        {

            float u = random(-1.0f, 1.0f);
            float theta = random(0, 2*PI);
            float x = sqrt(1-u*u)*cos(theta);
            float y = sqrt(1-u*u)*sin(theta);
            float z = u;

            PVector protonPos = new PVector(x*radius, y*radius, z*radius);
            PVector protonVel = new PVector(0, 0);
            RutherfordProton proton = new RutherfordProton(protonPos, protonVel, 3);
            nucleusParticles.add(proton);
        }
    }
}
public class RutherfordNeutron extends Particle
{
    public RutherfordNeutron(PVector position, PVector velocity, int radius)
    {
        super(position, velocity);
    }

    @Override
    public void drawParticle()
    {
        noStroke();
        fill(0xff4560E3);
        translate(getPosition().x, getPosition().y, getPosition().z);
        sphere(getRadius());
        stroke(0);
        translate(-getPosition().x, -getPosition().y, -getPosition().z);
    }
}
public class RutherfordProton extends Particle
{
    public RutherfordProton(PVector position, PVector velocity, int radius)
    {
        super(position, velocity);
    }

    @Override
    public void drawParticle()
    {
        noStroke();
        fill(0xffE34545);
        translate(getPosition().x, getPosition().y, getPosition().z);
        sphere(getRadius());
        stroke(0);
        translate(-getPosition().x, -getPosition().y, -getPosition().z);
    }
}
private class ThomsonElectron extends Particle
{
    private AtomModel container;

    public ThomsonElectron(AtomModel container, PVector position, PVector velocity)
    {
        super(position, velocity);
        this.container = container;
    }

    @Override
    public void drawParticle()
    {
        //move the electrons
        getPosition().add(getVelocity());

        //check and handle collisions
        if (getPosition().mag() + getRadius() >= container.getRadius()-1)
        {
            PVector position = new PVector(getPosition().x, getPosition().y, getPosition().z);
            PVector velocity = new PVector(getVelocity().x, getVelocity().y, getVelocity().z);
            PVector normal = position.mult(-1).normalize();
            PVector reflect = velocity.sub(normal.mult(2 * velocity.dot(normal)));
            setVelocity(reflect);
        }

        //draw the electrons
        noStroke();
        fill(204, 254, 255);
        translate(getPosition().x, getPosition().y, getPosition().z);
        sphere(getRadius());
        stroke(0);
        translate(-getPosition().x, -getPosition().y, -getPosition().z);
    }
}
private class ThomsonModel extends AtomModel
{
    private ArrayList<Particle> particles;

    private int numElectrons = 5;
    private int numProtons = 5;

    public ThomsonModel()
    {
        super("Thomson Model", 45, new PVector(300, height / 2));
        particles = new ArrayList<Particle>();

        //place the electrons in the models
        for (int i = 0; i < numElectrons; i++)
        {
            float u = random(-1.0f, 1.0f);
            float theta = random(0, 2*PI);
            float x = sqrt(1-u*u)*cos(theta);
            float y = sqrt(1-u*u)*sin(theta);
            float z = u;

            PVector elecPos = new PVector(x*(getRadius()-12), y*(getRadius()-12), z*(getRadius()-12));
            PVector elecVel = new PVector(random(-.5f, .5f), random(-.5f, .5f), random(-.5f, .5f));  
            particles.add(new ThomsonElectron(this, elecPos, elecVel));
        }
        
        //place the protons in the models
        for (int i = 0; i < numProtons; i++)
        {
            float u = random(-1.0f, 1.0f);
            float theta = random(0, 2*PI);
            float x = sqrt(1-u*u)*cos(theta);
            float y = sqrt(1-u*u)*sin(theta);
            float z = u;

            PVector protPos = new PVector(x*(getRadius()-12), y*(getRadius()-12), z*(getRadius()-12));
            PVector protVel = new PVector(0, 0, 0);  
            particles.add(new ThomsonProton(this, protPos, protVel));
        }
    }

    @Override
    public void drawModel()
    {
        super.drawModel();
        pushMatrix();
        translate(getPosition().x, getPosition().y);

        //draw the particles
        for (Particle p : particles)
            p.drawParticle();

        //draw the model
        noStroke();
        fill(205, 103, 204, 128);
        rotateX(-PI/6);
        sphere(getRadius());
        rotateX(PI/6);
        
        popMatrix();
    }
}
private class ThomsonProton extends Particle
{
    public ThomsonProton(AtomModel container, PVector position, PVector velocity)
    {
        super(position, velocity);
    }

    @Override
    public void drawParticle()
    {
        //draw the electrons
        noStroke();
        fill(0xffE34545);
        translate(getPosition().x, getPosition().y, getPosition().z);
        sphere(getRadius());
        stroke(0);
        translate(-getPosition().x, -getPosition().y, -getPosition().z);
    }
}
    public void settings() {  size(400, 400, P3D); }
    static public void main(String[] passedArgs) {
        String[] appletArgs = new String[] { "AtomAnimation" };
        if (passedArgs != null) {
          PApplet.main(concat(appletArgs, passedArgs));
        } else {
          PApplet.main(appletArgs);
        }
    }
}
