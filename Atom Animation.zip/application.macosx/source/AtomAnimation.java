import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class AtomAnimation extends PApplet {

float cameraX, cameraY;
float scaleFactor;
AtomModel[] models;
int modelsIndex;
PVector targetPos;
float cameraRotY, cameraRotX;

public void setup()
{
    
    scaleFactor = 1.0f;
    models = new AtomModel[5];
    models[0] = new DaltonModel();
    models[1] = new ThomsonModel();
    models[2] = new RutherfordModel();
    models[3] = new BohrModel();
    models[4] = new QuantumMechanicsModel();
    modelsIndex = 0;
    targetPos = new PVector(models[modelsIndex].position.x, models[modelsIndex].position.y);
    cameraX = targetPos.x;
    cameraY = targetPos.y;
    cameraRotY = 0;
    cameraRotX = 0;
}

public void draw()
{
    //set background and basic stroke colors
    background(255);
    lights();
    stroke(0);

    pushMatrix();
    //scale based on zoom
   
    translate(width / 2, height / 2);
    rotateY(cameraRotY);
    rotateX(cameraRotX);
    scale(scaleFactor);
    
    cameraX += (targetPos.x - cameraX) / 15;
    cameraY += (targetPos.y - cameraY) / 15;
    translate(-cameraX, -cameraY);

    for(int i = 0; i < models.length; i++)
        models[i].drawModel();
        
    popMatrix();
    text((int)frameRate, 12, 15);
}

public void keyPressed(KeyEvent e)
{
    if(e.getKeyCode() == LEFT && modelsIndex > 0)
       modelsIndex--;
    if(e.getKeyCode() == RIGHT && modelsIndex < models.length - 1)
        modelsIndex++;
    if(e.getKeyCode() == UP && scaleFactor < 7.0f)
        scaleFactor+=.5f;
    if(e.getKeyCode() == DOWN && scaleFactor > 1.0f)
        scaleFactor-=.5f;
    if(e.getKeyCode() == 'A')
        cameraRotY += PI/6;
    if(e.getKeyCode() == 'D')
        cameraRotY -= PI/6;
    if(e.getKeyCode() == 'W')
        cameraRotX -= PI/6;
    if(e.getKeyCode() == 'S')
        cameraRotX += PI/6;
    if(e.getKeyCode() == 'R')
        setup();
        
    targetPos = new PVector(models[modelsIndex].getPosition().x, models[modelsIndex].getPosition().y);
}
public abstract class AtomModel
{
    private String name;
    private int radius;
    private PVector position;
   

    public AtomModel(String name, int radius, PVector position)
    {
        this.name = name;
        this.radius = radius;
        this.position = position;
    }

    public abstract void drawModel();

    public String getName(){return name;}
    public PVector getPosition(){return position;}
    public int getRadius(){return radius;}
    
}
public class BohrElectron extends Particle
{
    private float orbitAngle;//angular position of particle
    private float orbitRadius;//radius of particle from center of atom
    private float angularVel;//velocity at which particle moves
    
    public BohrElectron(float orbitRadius)
    {
        super(new PVector(0, 0), new PVector(0, 0), 3);
        orbitAngle = random(0, 2 * PI);
        this.orbitRadius = orbitRadius;
        angularVel = random(.05f, .1f);
    }
    
    public void drawParticle()
    {
       orbitAngle += angularVel;
       float x = orbitRadius*cos(orbitAngle);
       float y = orbitRadius*sin(orbitAngle);
       setPosition(new PVector(x, y));
       
       noFill();
       stroke(1);
       ellipse(0, 0, orbitRadius*2, orbitRadius*2);
       
       noStroke();
       fill(204, 254, 255);
       pushMatrix();
       translate(getPosition().x, getPosition().y);
       sphere(getRadius());
       translate(-getPosition().x, -getPosition().y);
       popMatrix();
    }
}
public class BohrModel extends AtomModel
{
    private ArrayList<Particle> nucleusParticles;
    private ArrayList<Particle> orbitalParticles;
    
    private final int NUM_PROTONS = 3;
    private final int NUM_NEUTRONS = 3;
    private final int NUM_ELECTRONS = 3;
    
    public BohrModel()
    {
        super("Bohr Model", 25, new PVector(700, height / 2));
        nucleusParticles = new ArrayList<Particle>();
        orbitalParticles = new ArrayList<Particle>();
        generateNucleus();
        for(int i = 1; i <= NUM_ELECTRONS; i++)
            orbitalParticles.add(new BohrElectron(i*10));
    }
    
    public void drawModel()
    {
        pushMatrix();
        translate(getPosition().x, getPosition().y);
        
        for(Particle p : nucleusParticles)
           p.drawParticle();
        for(Particle p : orbitalParticles)
            p.drawParticle();
            
        fill(0);
        textSize(15);
        textAlign(CENTER);
        text(getName(), 0, NUM_ELECTRONS*10 + 15);
        popMatrix();
    }
    
    private void generateNucleus()
    {    
        int radius = 3;
        for(int i = 0; i < NUM_NEUTRONS; i++)
        {
           float u = random(-1.0f, 1.0f);
           float theta = random(0, 2*PI);
           float x = sqrt(1-u*u)*cos(theta);
           float y = sqrt(1-u*u)*sin(theta);
           float z = u;
           
           PVector neutronPos = new PVector(x*radius, y*radius, z*radius);
           PVector neutronVel = new PVector(0, 0);
           BohrNeutron neutron = new BohrNeutron(neutronPos, neutronVel, 3);
           nucleusParticles.add(neutron);
        }
        
        for(int i = 0; i < NUM_PROTONS; i++)
        {
            
         float u = random(-1.0f, 1.0f);
         float theta = random(0, 2*PI);
         float x = sqrt(1-u*u)*cos(theta);
         float y = sqrt(1-u*u)*sin(theta);
         float z = u;
            
         PVector protonPos = new PVector(x*radius, y*radius, z*radius);
         PVector protonVel = new PVector(0, 0);
         BohrProton proton = new BohrProton(protonPos, protonVel, 3);
         nucleusParticles.add(proton);
        }
        
    }
}
public class BohrNeutron extends Particle
{
    public BohrNeutron(PVector position, PVector velocity, int radius)
    {
        super(position, velocity, radius);
    }
    
    @Override
    public void drawParticle()
    {
       noStroke();
       fill(0xff4560E3);
       translate(getPosition().x, getPosition().y, getPosition().z);
       sphere(getRadius());
       stroke(0);
       translate(-getPosition().x, -getPosition().y, -getPosition().z);
    }
}
public class BohrProton extends Particle
{
    public BohrProton(PVector position, PVector velocity, int radius)
    {
        super(position, velocity, radius);
    }
    
    @Override
    public void drawParticle()
    {
       
       noStroke();
        fill(0xffE34545);
       translate(getPosition().x, getPosition().y, getPosition().z);
       sphere(getRadius());
       stroke(0);
       translate(-getPosition().x, -getPosition().y, -getPosition().z);
    }
}
public class DaltonModel extends AtomModel
{
    public DaltonModel()
    {
        super("Dalton Model", 45, new PVector(100, height / 2));
    }

    /**
     * draws the Dalton model of the atom
     *
     * @param centerX x coordinate to center the atom upon
     * @param centerY y coordinate to center the atom upon
     */
    @Override
    public void drawModel()
    {
        pushMatrix();
        translate(getPosition().x, getPosition().y);
        fill(205, 103, 204);
        noStroke();
        sphere(getRadius());
        textSize(15);
        textAlign(CENTER);
        fill(0);
        text(getName(), 0, getRadius() + 15);
        popMatrix();
    }    
}
public abstract class Particle
{
    private PVector position;
    private PVector velocity;
    private int radius;

    public Particle(PVector position, PVector velocity, int radius)
    {
        this.position = position;
        this.velocity = velocity;
        this.radius = radius;
    }
    
    public abstract void drawParticle();
    
    public PVector getPosition(){return position;}
    public void setPosition(PVector position){this.position = position;}
    public PVector getVelocity(){return velocity;}
    public void setVelocity(PVector velocity){this.velocity = velocity;}
    public int getRadius(){return radius;}
}
public class QuantumMechanicsModel extends AtomModel
{
    public QuantumMechanicsModel()
    {
        super("Quantum Mechanics Model", 25, new PVector(900, height / 2));
    }
    
    public void drawModel()
    {
       pushMatrix(); 
       translate(getPosition().x, getPosition().y);
       fill(0);
       textSize(15);
       textAlign(CENTER);
       text(getName(), 0, getRadius() + 15);
       popMatrix();
    }
}
public class RutherfordElectron extends Particle
{
    private float orbitAngle;//angular position of particle
    private float orbitRadius;//radius of particle from center of atom
    private float angularVel;//velocity at which particle moves
    private float orbitRotation;//angle at which the orbit occurs
    private float rotOffset;
    
    public RutherfordElectron(float orbitRotation)
    {
        super(new PVector(0, 0), new PVector(0, 0), 3);
        orbitAngle = random(0, 2 * PI);
        orbitRadius = 30;
        angularVel = random(.05f, .1f);
        this.orbitRotation = orbitRotation;
        rotOffset = random(-PI/6, PI/6);
    }
    
    public void drawParticle()
    {
       orbitAngle += angularVel;
       float x = orbitRadius*cos(orbitAngle);
       float y = orbitRadius/3f*sin(orbitAngle);

       setPosition(new PVector(x, y));
       rotateY(PI/2);
       rotateX(orbitRotation);
       rotateY(PI/4);
       //draw orbit ring
       noFill();
       ellipse(0, 0, orbitRadius*2, orbitRadius*2/3f);
       
       //draw electron
       noStroke();
       fill(204, 254, 255);
       translate(getPosition().x, getPosition().y);
       sphere(getRadius());
       stroke(0);
       translate(-getPosition().x, -getPosition().y);
       rotateY(-PI/4);
       rotateX(-orbitRotation);
       rotateY(-PI/2);
       
       //rotateY(-orbitRotation);
       
       
    }
}
public class RutherfordModel extends AtomModel
{
    private ArrayList<Particle> nucleusParticles;
    private ArrayList<Particle> orbitalParticles;
    
    private final int NUM_PROTONS = 7;
    private final int NUM_NEUTRONS = 7;
    private final int NUM_ELECTRONS = 7;
    
    public RutherfordModel()
    {
         super("Rutherford Model", 25, new PVector(500, height / 2));  
         nucleusParticles = new ArrayList<Particle>();
         orbitalParticles = new ArrayList<Particle>();
         generateNucleus();
         for(int i = 0; i < NUM_ELECTRONS; i++)
            orbitalParticles.add(new RutherfordElectron(-PI/4+ 2*PI/NUM_ELECTRONS*i));
         
    }
    
    public void drawModel()
    {
        pushMatrix();
        translate(getPosition().x, getPosition().y);

        for(Particle p : nucleusParticles)
            p.drawParticle();
        for(Particle p : orbitalParticles)
            p.drawParticle(); 
        
        fill(0);
        textSize(15);
        textAlign(CENTER);
        text(getName(), 0, 30 + 15);
        popMatrix();
    }
    
    private void generateNucleus()
    {    
        int radius = 3;
        for(int i = 0; i < NUM_NEUTRONS; i++)
        {
           float u = random(-1.0f, 1.0f);
           float theta = random(0, 2*PI);
           float x = sqrt(1-u*u)*cos(theta);
           float y = sqrt(1-u*u)*sin(theta);
           float z = u;
           
           PVector neutronPos = new PVector(x*radius, y*radius, z*radius);
           PVector neutronVel = new PVector(0, 0);
           RutherfordNeutron neutron = new RutherfordNeutron(neutronPos, neutronVel, 3);
           nucleusParticles.add(neutron);
        }
        
        for(int i = 0; i < NUM_PROTONS; i++)
        {
            
         float u = random(-1.0f, 1.0f);
         float theta = random(0, 2*PI);
         float x = sqrt(1-u*u)*cos(theta);
         float y = sqrt(1-u*u)*sin(theta);
         float z = u;
            
         PVector protonPos = new PVector(x*radius, y*radius, z*radius);
         PVector protonVel = new PVector(0, 0);
         RutherfordProton proton = new RutherfordProton(protonPos, protonVel, 3);
         nucleusParticles.add(proton);
        }
        
    }
    
}
public class RutherfordNeutron extends Particle
{
    public RutherfordNeutron(PVector position, PVector velocity, int radius)
    {
        super(position, velocity, radius);
    }
    
    @Override
    public void drawParticle()
    {
       noStroke();
       fill(0xff4560E3);
       translate(getPosition().x, getPosition().y, getPosition().z);
       sphere(getRadius());
       stroke(0);
       translate(-getPosition().x, -getPosition().y, -getPosition().z);
        
    }
}
public class RutherfordProton extends Particle
{
    public RutherfordProton(PVector position, PVector velocity, int radius)
    {
        super(position, velocity, radius);
    }
    
    @Override
    public void drawParticle()
    {
       
       noStroke();
       fill(0xffE34545);
       translate(getPosition().x, getPosition().y, getPosition().z);
       sphere(getRadius());
       stroke(0);
       translate(-getPosition().x, -getPosition().y, -getPosition().z);
    }
}
private class ThomasElectron extends Particle
{
    private AtomModel container;

    public ThomasElectron(AtomModel container, PVector position, PVector velocity)
    {
        super(position, velocity, 6);
        this.container = container;
    }

    @Override
    public void drawParticle()
    {
        getPosition().add(getVelocity());

        if(getPosition().mag() + getRadius() >= container.getRadius()-1)
        {
            PVector position = new PVector(getPosition().x, getPosition().y, getPosition().z);
            PVector velocity = new PVector(getVelocity().x, getVelocity().y, getVelocity().z);
            PVector normal = position.mult(-1).normalize();
            PVector reflect = velocity.sub(normal.mult(2 * velocity.dot(normal)));
            setVelocity(reflect);
        }
         
        noStroke();
        fill(204, 254, 255);
        translate(getPosition().x, getPosition().y, getPosition().z);
        sphere(getRadius());
        stroke(0);
        translate(-getPosition().x, -getPosition().y, -getPosition().z);
 //<>//
    }
}
private class ThomsonModel extends AtomModel
{
    private ArrayList<Particle> particles;
   
    private final int NUM_ELECTRONS = 5;
    
    public ThomsonModel()
    {
        super("Thomson Model", 45, new PVector(300, height / 2));
        particles = new ArrayList<Particle>();
        
        for(int i = 0; i < NUM_ELECTRONS; i++)
        {
            PVector elecPos = new PVector(random(-getRadius() + 12, getRadius() - 12), random(-getRadius() + 12, getRadius() - 12), random(-getRadius() + 12, getRadius() - 12));
            PVector elecVel = new PVector(random(-.5f, .5f), random(-.5f, .5f), random(-.5f, .5f));  
            particles.add(new ThomasElectron(this, elecPos, elecVel));
        }
    }

    /**
     * draws the Thomson model of the atom
     *
     * @param centerX x coordinate to center the atom upon
     * @param centerY y  to center the atom upon
     */
    @Override
    public void drawModel()
    {
        pushMatrix();
        
        translate(getPosition().x, getPosition().y);
        for(Particle p : particles)
            p.drawParticle();
            
        noStroke();
        fill(205, 103, 204, 128);
        sphere(getRadius());
        


        fill(0);
        textSize(15);
        textAlign(CENTER);
        text(getName(), 0, getRadius() + 15);
        popMatrix();
    }
}
public class ThomasProton extends Particle
{
    private AtomModel container;
    
    public ThomasProton(AtomModel container, PVector position, PVector velocity)
    {
        super(position, velocity, 3);
        this.container = container;
    }

    @Override
    public void drawParticle()
    {
        stroke(249, 192, 160, 127);
        //vertical line
        line(getPosition().x, getPosition().y + getRadius(), getPosition().x, getPosition().y - getRadius());
        //horizontal line
        line(getPosition().x - getRadius(), getPosition().y, getPosition().x + getRadius(), getPosition().y);
        stroke(1);
 
    }   
}
    public void settings() {  size(400, 400, P3D); }
    static public void main(String[] passedArgs) {
        String[] appletArgs = new String[] { "AtomAnimation" };
        if (passedArgs != null) {
          PApplet.main(concat(appletArgs, passedArgs));
        } else {
          PApplet.main(appletArgs);
        }
    }
}
